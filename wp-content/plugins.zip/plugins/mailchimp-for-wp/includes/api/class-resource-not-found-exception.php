<?php

class MC4WP_API_Resource_Not_Found_Exception extends MC4WP_API_Exception {}
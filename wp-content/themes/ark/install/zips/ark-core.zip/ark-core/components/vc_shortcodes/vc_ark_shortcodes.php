<?php

if( function_exists('vc_map') ){

	require dirname( __FILE__ ) . '/ark_messagebox.php';
	require dirname( __FILE__ ) . '/ark_button.php';
	require dirname( __FILE__ ) . '/ark_progressbar.php';

}
